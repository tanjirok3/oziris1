class Reboot:
    
    def __init__(self):
        os.system("shutdown /r /t 1")